/* goodbye.c */
#include <stdio.h>
void goodbye(void) {
  printf("Goodbye!\n");
}
