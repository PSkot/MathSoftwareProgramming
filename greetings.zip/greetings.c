/* greetings.c */
#include "hello.h"
#include "goodbye.h"
int main(void) {
  hello();
  goodbye();
  return 0;
}
