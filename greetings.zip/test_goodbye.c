/* test_goodbye.c */
#include "goodbye.h"
int main(void) {
  goodbye();
  return 0;
}
