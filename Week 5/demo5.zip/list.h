#ifndef LIST_H
#define LIST_H

#include <stdlib.h>

#define LIST_SUCCESS 0
#define LIST_FAILURE 1
#define LIST_LENGTH(L) (L->n)
#define LIST_PUSH(L,x) list_insert(L,LIST_LENGTH(L),x)

typedef struct elem elem_t;
typedef struct list list_t;

struct elem {
  double x;      /* "payload" */
  elem_t *next;
};

struct list {
  size_t n;
  elem_t *head;
};

list_t * list_malloc(void);
void list_free(list_t *L);
int list_insert(list_t *L, size_t i, double val);
int list_delete(list_t *L, size_t i);
int list_at(list_t *L, size_t i, double *val);
void list_print(list_t *L);
list_t * list_split(list_t *L, size_t i);
list_t * list_concat(list_t *L1, list_t *L2);

#endif
