#include <stdio.h>
#include "list.h"

int main(void) {

  double x;

  // Allocate new list (empty)
  list_t *L = list_malloc();
  if (L==NULL) return EXIT_FAILURE;

  // Insert 1.0 at index 0
  list_insert(L, 0, 1.0);
  list_print(L);

  // Insert 2.0 at index 1
  list_insert(L, 1, 2.0);
  list_print(L);

  // Insert 3.0 at end of list
  LIST_PUSH(L,3.0);
  list_print(L);

  // Insert 4.0 at end of list
  LIST_PUSH(L,4.0);
  list_print(L);

  // Insert 1.5 at index 1
  list_insert(L, 1, 1.5);
  list_print(L);

  // Delete last element
  list_delete(L, LIST_LENGTH(L)-1);
  list_print(L);

  // Delete element at index 2
  list_delete(L, 2);
  list_print(L);

  // Get element at index 2
  list_at(L,2,&x);
  printf("Element at index 2: %f\n",x);

  // Delete element at index 0
  list_delete(L, 0);
  list_print(L);

  // Free list
  list_free(L);

  return 0;
}
