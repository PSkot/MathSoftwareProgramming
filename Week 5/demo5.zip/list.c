#include <stdio.h>
#include "list.h"

/* allocate and initialize list */
list_t * list_malloc(void) {
  list_t *L = malloc(sizeof(*L));
  if (L==NULL) return NULL;
  L->n = 0;
  L->head = NULL;
  return L;
}

/* free list elements and list */
void list_free(list_t *L) {
  elem_t *e, *tmp;
  if (L==NULL) return;
  /* free all list elements */
  e = L->head;
  while(e != NULL) {
    tmp = e->next;
    free(e);
    e = tmp;
  }
  /* free list */
  free(L);
}

int list_insert(list_t *L, size_t i, double val) {
  elem_t *e, *f;
  size_t k;
  if (L==NULL) return LIST_FAILURE;
  if (i>L->n) return LIST_FAILURE;
  /* allocate new list element */
  f = malloc(sizeof(*f));
  if (f==NULL) return LIST_FAILURE;
  /* insert new list element */
  f->x = val;
  e = L->head;
  if (i==0) {  // insert element at head
    f->next = e;
    L->head = f;
  }
  else {       // find element before place of insertion
    for (k=0;k<i-1;k++)
      e = e->next;
    // insert element
    f->next = e->next;
    e->next = f;
  }
  /* update length of list */
  L->n += 1;
  return LIST_SUCCESS;
}

int list_delete(list_t *L, size_t i) {
  elem_t *e, *f;
  size_t k;
  if (L==NULL) return LIST_FAILURE;
  if (i>=L->n || L->n == 0) return LIST_FAILURE;
  /* delete list element */
  e = L->head;
  if (i==0) {  // delete from head
    L->head = e->next;
    free(e);
  }
  else {       // find element before element to be deleted
    for (k=0;k<i-1;k++)
      e = e->next;
    // delete element and free memory
    f = e->next;
    e->next = f->next;
    free(f);
  }
  // update length of list
  L->n -= 1;
  return LIST_SUCCESS;
}

int list_at(list_t *L, size_t i, double *val) {
  elem_t *e;
  size_t k;
  if (L==NULL) return LIST_FAILURE;
  if (i>=L->n) return LIST_FAILURE;
  // find desired element
  e = L->head;
  for (k=0;k<i;k++)
    e = e->next;
  *val = e->x;
  return LIST_SUCCESS;
}

void list_print(list_t *L) {
  elem_t *e;
  size_t k;
  if (L==NULL) return;
  e = L->head;
  printf("list of length %zu\n",LIST_LENGTH(L));
  for (k=0;k<L->n;k++) {
    printf("%g ",e->x);
    e = e->next;
  }
  putchar('\n');
}

list_t * list_split(list_t *L, size_t i) {
  /* not yet implemented */
  return NULL;
}

list_t * list_concat(list_t *L1, list_t *L2) {
  /* not yet implemented */
  return NULL;
}
