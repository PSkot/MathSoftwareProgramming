#include "matrix_io.h"

/* dot
Purpose:
  Computes the inner product of two vectors.

Arguments:
  px         a pointer to a vector_t
  py         a pointer to a vector_t
  xy         a pointer to a double

Return value:
  An int with one of the following values:
   - MATRIX_IO_SUCCESS if no error occured
   - MATRIX_IO_ILLEGAL_INPUT if an input is NULL
   - MATRIX_IO_DIMENSION_MISMATCH if the vectors have diff. len.
*/
int dot(const vector_t * px, const vector_t * py, double * xy) {

  /* Insert code here */

}
