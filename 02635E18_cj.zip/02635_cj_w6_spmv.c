#include "sparse_triplet.h"

void sparse_triplet_mv(
          const struct sparse_triplet *A,
          const double *x,
          double *y)
{
    if (A!=NULL && x!=NULL && y!=NULL) {
        for (size_t i=0;i<A->nnz;i++)
            y[A->I[i]] += A->V[i]*x[A->J[i]];
    }
    return;
}
