#include "sparse_triplet.h"

void sparse_triplet_trans(struct sparse_triplet *A) {
    size_t tmp, *ptmp;
    if (A!=NULL) {
        /* Switch row and col indices */
        ptmp = A->I;
        A->I = A->J;
        A->J = ptmp;
        /* Switch dimensions */
        tmp = A->m;
        A->m = A->n;
        A->n = tmp;
    }
    return;
}
