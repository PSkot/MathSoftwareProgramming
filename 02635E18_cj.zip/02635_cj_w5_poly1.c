#include <math.h>
#include "polynomial.h"

double poly_eval(poly_t *p, double x) {
    unsigned int i;
    double res = 0.0;
    if (p==NULL||p->coef==NULL) return NAN;
    for (i=0;i<=p->n;i++)
        res = res*x + p->coef[p->n-i];
    return res;
}
