#include "matrix_io.h"

/* norm2
Purpose:
  Computes the Euclidean norm of a vector.

Arguments:
  px         a pointer to a vector_t
  nrm        a pointer to a double

Return value:
  An int with one of the following values:
   - MATRIX_IO_SUCCESS if no error occured
   - MATRIX_IO_ILLEGAL_INPUT if an input is NULL
   - MATRIX_IO_DIMENSION_MISMATCH if the vector has length 0
*/
int norm2(const vector_t *px, double *nrm) {
  size_t i;
  if (px == NULL || nrm == NULL) {
    INPUT_ERR;
    return MATRIX_IO_ILLEGAL_INPUT;
  }
  if (px->n == 0) {
    DIMENSION_ERR;
    return MATRIX_IO_DIMENSION_MISMATCH;
  }
  *nrm = 0;
  for (i = 0; i < px->n; i++)
    *nrm += (px->v[i]) * (px->v[i]);
  *nrm = sqrt(*nrm);
  return MATRIX_IO_SUCCESS;
}
