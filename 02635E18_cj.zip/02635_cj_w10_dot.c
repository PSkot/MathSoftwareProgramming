#include "matrix_io.h"

/* dot
Purpose:
  Computes the inner product of two vectors.

Arguments:
  px         a pointer to a vector_t
  py         a pointer to a vector_t
  xy         a pointer to a double

Return value:
  An int with one of the following values:
   - MATRIX_IO_SUCCESS if no error occured
   - MATRIX_IO_ILLEGAL_INPUT if an input is NULL
   - MATRIX_IO_DIMENSION_MISMATCH if the vectors have diff. len.
*/
int dot(const vector_t * px, const vector_t * py, double * xy) {
  size_t i;
  if ( px == NULL || py == NULL || xy == NULL ) {
    INPUT_ERR;
    return MATRIX_IO_ILLEGAL_INPUT;
  }
  if ( px->n != py->n || px->n == 0 ) {
    DIMENSION_ERR;
    return MATRIX_IO_DIMENSION_MISMATCH;
  }
  *xy = 0;
  for (i=0;i<px->n;i++)
    *xy += (px->v[i]) * (py->v[i]);
  return MATRIX_IO_SUCCESS;
}
