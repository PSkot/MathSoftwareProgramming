#include "matrix_io.h"

/* norm_fro_sparse
Purpose:
  Computes the Frobenius norm of a sparse matrix in triplet form.

Arguments:
  pA         a pointer to a matrix_t
  nrm        a pointer to a double

Return value:
  An int with one of the following values:
   - MATRIX_IO_SUCCESS if no error occured
   - MATRIX_IO_ILLEGAL_INPUT if an input is NULL
   - MATRIX_IO_DIMENSION_MISMATCH if one of the matrix dim. is 0
*/
int norm_fro_sparse(const sparse_triplet_t * pA, double * nrm) {
  size_t i;
  if ( pA == NULL || nrm == NULL ) {
    INPUT_ERR;
    return MATRIX_IO_ILLEGAL_INPUT;
  }
  if ( pA->m == 0 || pA->n == 0 ) {
    DIMENSION_ERR;
    return MATRIX_IO_DIMENSION_MISMATCH;
  }
  *nrm = 0;
  for (i=0;i<pA->nnz;i++)
      *nrm += (pA->V[i])*(pA->V[i]);
  *nrm = sqrt(*nrm);
  return MATRIX_IO_SUCCESS;
}
