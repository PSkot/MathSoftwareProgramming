#include "polynomial.h"

poly_t * poly_mul(const poly_t * p1, const poly_t * p2) {

    unsigned int i,j;
    poly_t * q;

    /* Handle NULL input */
    if (p1==NULL || p2==NULL) return NULL;

    /* Allocate new polynomial of degree
       n = p1->n + p2->n */
    q = poly_new(p1->n + p2->n);
    if (q==NULL) return NULL;

    /* Compute coefficients and return pointer */
    for (i=0;i<=p1->n;i++) {
        for (j=0;j<=p2->n;j++)
            q->coef[i+j] += p1->coef[i]*p2->coef[j];
    }
    return q;
}
