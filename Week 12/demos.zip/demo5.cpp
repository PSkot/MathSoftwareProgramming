#include <iostream>

class vect {
private:
  int n;       // length of vector
public:
  double *x;   // pointer to first of n values

  // Constructor 1 (no initialization of array)
  vect(int len) : n(len), x(new double[len]) {}

  // Constructor 2 (initializes array with value)
  vect(int len, double value) : n(len), x(new double[len]) {
    for(int i = 0; i < n; i++) x[i] = value;
  }

  // Copy constructor
  vect(const vect &v){
    n = v.n;
    x = new double[v.n];
    for(int i = 0; i < n; i++) x[i] = v.x[i];
  }

  // Destructor
  ~vect() { delete[] x; }

  // Length of vector
  int len() { return n; }

  // Print vector
  void print() {
    for (int i = 0; i < n; i++)
      std::cout << "x[" << i << "] = " << x[i] << std::endl;
  }

  // Assignment operator
  void operator=(double val) {
    for (int i = 0; i < n; i++)
      x[i] = val;
  }

  // Addition assignment operator
  void operator+=(vect &v1) {
    for (int i = 0; i < n; i++)
      x[i] += v1.x[i];
  }
};


int main(int argc, const char *argv[]) {

  vect v1 = vect(4);      // Constructor 1
  vect v2 = vect(4,2.0);  // Constructor 2 (initialize with value)
  vect v3 = vect(v2);     // Copy constructor

  v1 = 1.0;               // operator=
  v2 += v3;               // operator+=

  std::cout << "v1 (n=" << v1.len() << ")" << std::endl;
  v1.print();
  std::cout << "v2 (n=" << v2.len() << ")" << std::endl;
  v2.print();
  std::cout << "v3 (n=" << v3.len() << ")" << std::endl;
  v3.print();

  return 0;
}
