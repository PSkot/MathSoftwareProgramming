#include <iostream>

class rectangle {
public:
  double x;
  double y;
  double area() { return x * y; }
};

int main(int argc, const char *argv[]) {
  rectangle R;
  R.x = 1.0;
  R.y = 2.0;
  std::cout << "Area: " << R.area() << std::endl;
  std::cout << "sizeof(R): " << sizeof(R) << std::endl;
};
