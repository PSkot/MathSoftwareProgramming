#include <iostream>

int main(int argc, char const *argv[]) {

  int i;
  std::cout << "Enter an integer: ";
  if (std::cin >> i)
    std::cout << "You entered " << i << "!\n";
  else
    std::cout << "Ups. You did not enter an integer..\n";

  return 0;
}
