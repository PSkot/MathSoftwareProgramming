#include <cmath>
#include <iostream>

struct point {
  double x;
  double y;
  double distance(point &p) {
    return sqrt((x-p.x)*(x-p.x) + (y-p.y)*(y-p.y));
  }
};

int main(int argc, const char *argv[]) {
  point P1, P2;
  P1.x = 1;
  P1.y = 3;
  P2.x = 2;
  P2.y = 4;
  std::cout << P1.distance(P2) << std::endl;
  return 0;
}
