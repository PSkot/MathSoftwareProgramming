#include <stdlib.h>
#include <stdio.h>

long fibonacci(long n) {
  if ( n == 0 )
    return 0;
  else if ( n == 1 )
    return 1;
  else
    return fibonacci(n-1) + fibonacci(n-2);
}


int main(int argc, char const *argv[]) {
  long n = 0;
  if (argc != 2) {
    fprintf(stderr,"Usage: %s n\n",argv[0]);
    return EXIT_FAILURE;
  }
  n = atoi(argv[1]);
  printf("f(%ld) = %ld\n",n,fibonacci(n));
  return EXIT_SUCCESS;
}
