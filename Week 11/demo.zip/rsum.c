#include <stdlib.h>
#include <stdio.h>

#define Nbase 4
double recursive_sum(int n, const double * x) {
    // Base case
    if (n <= Nbase) {
        double psum = 0.0;
        for (int k=0;k<n;k++)
            psum += x[k];
        return psum;
    }
    // Recursive case
    int half = n/2;
    double psum1 = recursive_sum(half,x);
    double psum2 = recursive_sum(n-half,x+half);
    return psum1+psum2;
}


int main(int argc, char const *argv[]) {

    int N = 0;
    double sum=0.0, *arr;

    // Check input parameter
    if (argc != 2) {
        fprintf(stderr,"Usage: %s N\n",argv[0]);
        return EXIT_FAILURE;
    }

    // Convert input argument to integer
    N = atoi(argv[1]);

    // Allocate array
    if ((arr = malloc(N*sizeof(double))) == NULL) {
        fprintf(stderr,"Error: memory allocation failed.\n");
        return EXIT_FAILURE;
    }

    // Initialize array
    for (int i=0;i<N;i++) arr[i] = 1.0;

    // Compute and print sum
    sum = recursive_sum(N, arr);
    printf("sum(arr) = %g\n",sum);

    // Free memory
    free(arr);

    return 0;
}
