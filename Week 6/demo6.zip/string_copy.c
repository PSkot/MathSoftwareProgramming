#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define NON_INIT "[ \e[31muninitialized\e[39m ]" // Bash: red text
#define clear() printf("\033[H\033[J")           // Bash: clear screen

int main(int argc, char const *argv[]) {

  char buffer1[] = "not the string we expected";
  char buffer2[8];
  char str[] = "This is a long string";

  clear();
  #ifdef _FORTIFY_SOURCE
    printf("Info: compiled with _FORTIFY_SOURCE=%d\n\n",_FORTIFY_SOURCE);
  #endif

  switch (argc) {
    case 2:
      if (strlen(argv[1]) != 1) printf("Option must be a single character\n");
      else break;
    default:
      printf("Usage: %s option\n",argv[0]);
      exit(0);
  }

  printf("Initial content of char arrays:\n");
  printf(" buffer1 : %s\n", buffer1);
  printf(" buffer2 : %s\n", NON_INIT);
  printf(" str     : %s\n\n", str);

  switch (argv[1][0]) {
    case '1':
      printf("Coping str to buffer2 using strcpy(dest, src)\n\n");
      strcpy(buffer2, str);
      break;
    case '2':
      printf("Coping str to buffer2 using strncpy(dest, src, len)\n\n");
      strncpy(buffer2, str, sizeof(buffer2));
      break;
    case '3':
      printf("Coping str to buffer2 using strncpy(dest, src, len) "
             "with manual termination\n\n");
      strncpy(buffer2, str, sizeof(buffer2));
      buffer2[sizeof(buffer2)-1] = '\0';
      break;
    case '4':
      printf("Coping str to buffer2 using snprintf(dst_size, dst, \"%%s\", src)\n\n");
      snprintf(buffer2, sizeof(buffer2), "%s", str);
      break;
    case '5':
#if defined(__MACH__) || defined(linux)
      // Alternative (macOS/Linux):
      printf("Coping str to buffer2 using strlcpy(dest, src, len)\n\n");
      strlcpy(buffer2, str, sizeof(buffer2));
#else
      printf("Ups.. strlcpy() may not be available.\n\n")
#endif
      break;
    default:
      printf("Unknown option: %c\n\n",argv[1][0]);
      return 0;
  }

  // Print content of arrays
  printf("Content of char arrays:\n");
  printf(" buffer1 : %s\n"
         " buffer2 : %s\n"
         " str     : %s\n\n", buffer1, buffer2, str);

  // Print memory address of buffers
  printf("Addresses:\n");
  printf(" buffer1 : %p\n"
         " buffer2 : %p\n"
         " str     : %p\n", buffer1, buffer2, str);


  return 0;
}
