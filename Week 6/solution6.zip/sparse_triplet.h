#ifndef SPARSE_TRIPLET_H
#define SPARSE_TRIPLET_H

#include <stdlib.h>

/* Return values used to indicate success/failure */ 
#define ST_SUCCESS 0
#define ST_FAILURE 1

/* Structure representing a sparse matrix in triplet form */
struct sparse_triplet {
  size_t m;   /* number of rows     */
  size_t n;   /* number of columns  */
  size_t nnz; /* number of nonzeros */
  size_t *I;  /* pointer to array with row indices    */
  size_t *J;  /* pointer to array with column indices */
  double *V;  /* pointer to array with values         */
};

struct sparse_triplet *read_sparse(const char *filename);
int write_sparse(const char *filename, struct sparse_triplet *A);
void free_sparse(struct sparse_triplet *A);

#endif
