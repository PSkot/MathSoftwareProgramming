#include <stdio.h>
#include <float.h>
#include "sparse_triplet.h"

/* Reads a sparse matrix from a file.

Arguments
  filename    string (char array)

Return value
  The function returns a pointer to a struct sparse_triplet, and NULL is
  returned in case of failure.

Memory:
  The function allocates a struct sparse_triplet. It is the caller's
  responsibility to deallocate this using free_sparse().
*/
struct sparse_triplet * read_sparse(const char * filename) {

  FILE *fp;
  size_t i,m,n,nnz;
  struct sparse_triplet * A;

  // Open file and read dimensions
  if ((fp = fopen(filename, "r")) == NULL ) {
    perror("File error");
    return NULL;
  }
  if (fscanf(fp,"%zu %zu %zu",&m,&n,&nnz) != 3) {
    fprintf(stderr, "Failed to read matrix dimensions.\n");
    fclose(fp);
    return NULL;
  }

  /* Allocate sparse_triplet structure */
  A = malloc(sizeof(struct sparse_triplet));
  if ( A == NULL ) {
    fprintf(stderr,"Memory allocation failed.\n");
    fclose(fp);
    return NULL;
  }
  A->m = m;
  A->n = n;
  A->nnz = nnz;
  A->I = malloc(nnz*sizeof(*(A->I)));
  A->J = malloc(nnz*sizeof(*(A->J)));
  A->V = malloc(nnz*sizeof(*(A->V)));
  if ( A->I == NULL || A->J == NULL || A->V == NULL ) {
    fprintf(stderr,"Memory allocation failed.\n");
    free_sparse(A);
    fclose(fp);
    return NULL;
  }

  /* Read triplets and subtract 1 from indices */
  for (i=0;i<nnz;i++) {
    if ( fscanf(fp,"%zu %zu %lf",A->I+i,A->J+i,A->V+i)==3 ) {
      A->I[i]--;
      A->J[i]--;
    }
    else {
      fprintf(stderr, "Failed to read entry on line %zu.\n",i+2);
      free_sparse(A);
      fclose(fp);
      return NULL;
    }
  }

  /* Close file and return pointer to sparse_triplet structure */
  fclose(fp);
  return A;
}

/* Writes a struct sparse_triplet to a file.

Arguments
  filename    string (char array)
  A           struct sparse_triplet

Return value
  If successful, the function returns ST_SUCCESS, and otherwise ST_FAILURE
  is returned.
*/
int write_sparse(const char * filename, struct sparse_triplet * A) {

  size_t i;
  FILE *fp;

  /* Check that A is not NULL */
  if ( A == NULL ) return ST_FAILURE;

  /* Open file for writing */
  fp = fopen(filename,"w");
  if ( fp == NULL ) {
    perror("File error");
    return ST_FAILURE;
  }

  /* Write sparse_triplet structure to file */
  fprintf(fp,"%zu %zu %zu\n",A->m,A->n,A->nnz);
  for (i=0;i<A->nnz;i++) // Use format specifier .17g to avoid loss of precision
    fprintf(fp,"%zu %zu %.17g\n",A->I[i],A->J[i],A->V[i]);
  fclose(fp);

  return ST_SUCCESS;
}

/* Frees dynamically allocated struct sparse_triplet. */
void free_sparse(struct sparse_triplet * A) {
    if ( A == NULL ) return;
    free(A->I);
    free(A->J);
    free(A->V);
    free(A);
    return;
}
