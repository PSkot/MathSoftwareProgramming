#include <stdio.h>
#include "sparse_triplet.h"

int main(int argc, char const *argv[]) {

  size_t i;
  FILE *fp;

  if (argc != 3) {
    fprintf(stderr,"Usage: %s infile outfile\n",argv[0]);
    return EXIT_FAILURE;
  }

  // Read sparse triplet from file
  struct sparse_triplet *A = read_sparse(argv[1]);
  if ( A == NULL ) return EXIT_FAILURE;

  // Print triplets
  for (i=0;i<A->nnz;i++)
    printf("%zu %zu %g\n",A->I[i],A->J[i],A->V[i]);

  // Naive way to check if output file exists: try opening in read mode
  if ((fp = fopen(argv[2],"r")) == NULL) {
    // Couldn't open file in read mode: try writing sparse triplet to file
    if ( write_sparse(argv[2],A) == ST_SUCCESS )
      printf("Successfully exported matrix in triplet form.\n");
    else {
      printf("Failed to write matrix in triplet form to file.\n");
      free_sparse(A);
      return EXIT_FAILURE;
    }
  }
  else {
    // Output file already exists
    fprintf(stderr,"File %s already exists.\n",argv[2]);
    free_sparse(A);
    return EXIT_FAILURE;
  }

  // Clean up and return
  free_sparse(A);
  return EXIT_SUCCESS;
}
